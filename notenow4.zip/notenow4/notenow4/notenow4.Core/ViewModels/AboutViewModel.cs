﻿using MvvmCross.Core.ViewModels;

namespace notenow4.Core.ViewModels
{
    public class AboutViewModel : MvxViewModel
    {
    }
}
