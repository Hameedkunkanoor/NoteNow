﻿namespace notenow4.Core.Pages
{
    public partial class AboutPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}
