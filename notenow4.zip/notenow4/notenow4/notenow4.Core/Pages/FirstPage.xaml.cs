﻿namespace notenow4.Core.Pages
{
    public partial class FirstPage
    {
        public FirstPage()
        {
            InitializeComponent();
        }
    }
}
